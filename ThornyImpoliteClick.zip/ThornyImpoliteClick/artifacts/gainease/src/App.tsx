import { type ChangeEvent, type FormEvent, type ReactNode, useEffect, useState } from 'react';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { frFR } from '@clerk/localizations';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowUpRight,
  BadgeCheck,
  Banknote,
  BarChart3,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Clock3,
  Copy,
  CreditCard,
  FileCheck2,
  FileImage,
  Gift,
  Home as HomeIcon,
  Image as ImageIcon,
  KeyRound,
  Landmark,
  LayoutDashboard,
  ListChecks,
  LogOut,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Play,
  RefreshCw,
  ShieldCheck,
  Send,
  Sparkles,
  TicketCheck,
  Trash2,
  TrendingUp,
  UserRound,
  Users,
  WalletCards,
  X,
  XCircle,
} from 'lucide-react';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import paypalLogo from '@assets/file_0000000084d881f4a9614f1a00a0b98b_1788259639106.png';
import bankLogo from '@assets/Screenshot_20260830-142955_1788259639052.jpg';

const queryClient = new QueryClient();
const KEYS = { users: 'gainease:users', activities: 'gainease:activities', withdrawals: 'gainease:withdrawals', vouchers: 'gainease:vouchers', logs: 'gainease:logs', support: 'gainease:support-messages', current: 'gainease:current-user', token: 'gainease:token', failures: 'gainease:login-failures' };
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

type WithdrawalStatus = 'blocked' | 'pending' | 'unlocked';
type WithdrawalState = 'pending' | 'approved' | 'rejected' | 'paid';
type User = { id: string; name: string; email: string; passwordHash: string; isAdmin: boolean; avatar: string; createdAt: string; videoViews: number; totalEarned: number; referrals: number; withdrawalStatus: WithdrawalStatus; referralCode: string };
type Activity = { id: string; userId: string; type: 'video' | 'referral' | 'bonus'; title: string; reward: number; completedAt: string };
type Withdrawal = { id: string; userId: string; amount: number; method: string; details?: string; status: WithdrawalState; createdAt: string };
type VoucherSubmission = { id: string; userId: string; codeImage: string; name: string; status: 'pending' | 'approved' | 'rejected'; submittedAt: string };
type AppLog = { id: string; action: string; actor: string; createdAt: string };
type SupportMessage = { id: string; userId: string; sender: 'user' | 'admin'; text: string; createdAt: string; read: boolean };

const read = <T,>(key: string, fallback: T): T => {
  try { return JSON.parse(localStorage.getItem(key) || '') as T; } catch { return fallback; }
};
const write = (key: string, value: unknown) => localStorage.setItem(key, JSON.stringify(value));
const id = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
const money = (value: number) => `${value.toFixed(2).replace('.', ',')} €`;
const dateLabel = (value: string) => new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(value));
const hashPassword = (value: string) => btoa(unescape(encodeURIComponent(value)));
const currentUser = () => {
  const currentId = localStorage.getItem(KEYS.current);
  return read<User[]>(KEYS.users, []).find((user) => user.id === currentId);
};
const initials = (name: string) => name.split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase();
const addLog = (action: string, actor: string) => write(KEYS.logs, [{ id: id('log'), action, actor, createdAt: new Date().toISOString() }, ...read<AppLog[]>(KEYS.logs, [])]);

type ClerkIdentity = {
  id: string;
  firstName: string | null;
  lastName: string | null;
  primaryEmailAddress?: { emailAddress: string } | null;
};

function syncLocalUser(identity: ClerkIdentity) {
  const email = identity.primaryEmailAddress?.emailAddress?.toLowerCase();
  if (!email) return;
  const name = [identity.firstName, identity.lastName].filter(Boolean).join(' ') || email.split('@')[0];
  const users = read<User[]>(KEYS.users, []);
  const existing = users.find((item) => item.email === email);
  const localUser: User = existing || {
    id: id('user'),
    name,
    email,
    passwordHash: '',
    isAdmin: users.length === 0,
    avatar: initials(name),
    createdAt: new Date().toISOString(),
    videoViews: 0,
    totalEarned: 0,
    referrals: 0,
    withdrawalStatus: 'blocked',
    referralCode: `GAIN-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
  };
  write(KEYS.users, existing ? users.map((item) => item.id === existing.id ? { ...item, name, avatar: initials(name) } : item) : [...users, localUser]);
  localStorage.setItem(KEYS.current, localUser.id);
  localStorage.setItem(KEYS.token, `clerk.${identity.id}`);
}

function Flash({ message, tone = 'success', onClose }: { message: string; tone?: 'success' | 'error' | 'info'; onClose: () => void }) {
  return <div className={`fixed right-4 top-4 z-[70] flex max-w-sm items-center gap-3 rounded-2xl border px-4 py-3 text-sm font-semibold shadow-xl animate-in ${tone === 'success' ? 'border-teal-200 bg-[#e4fbf6] text-[#087b6e]' : tone === 'error' ? 'border-red-200 bg-red-50 text-red-700' : 'border-blue-200 bg-blue-50 text-blue-700'}`} role="status" data-testid="status-toast">
    {tone === 'success' ? <CheckCircle2 size={18} /> : tone === 'error' ? <XCircle size={18} /> : <CircleHelp size={18} />}
    <span>{message}</span><button onClick={onClose} aria-label="Fermer" data-testid="button-close-toast"><X size={16} /></button>
  </div>;
}

function useFlash() {
  const [flash, setFlash] = useState<{ message: string; tone?: 'success' | 'error' | 'info' } | null>(null);
  const notify = (message: string, tone: 'success' | 'error' | 'info' = 'success') => setFlash({ message, tone });
  return { flash, notify, clear: () => setFlash(null) };
}

function Logo({ light = false }: { light?: boolean }) {
  return <Link href="/" className="flex items-center gap-2.5" data-testid="link-logo">
    <span className={`grid h-9 w-9 place-items-center rounded-xl ${light ? 'bg-white/15 text-[#65efe0]' : 'bg-gradient-to-br from-[#1A2980] to-[#26D0CE] text-white'} shadow-sm`}><TrendingUp size={19} strokeWidth={2.8} /></span>
    <span className={`text-[17px] font-extrabold tracking-[-0.05em] ${light ? 'text-white' : 'text-[#1a285a]'}`}>Gain<span className={light ? 'text-[#65efe0]' : 'text-[#0daaa4]'}>Ease</span></span>
  </Link>;
}

function Avatar({ user, small = false }: { user: User; small?: boolean }) {
  return <div className={`${small ? 'h-8 w-8 text-[11px]' : 'h-10 w-10 text-xs'} grid shrink-0 place-items-center rounded-full bg-[#d9f5f1] font-extrabold text-[#087b6e]`} data-testid="img-avatar">{user.avatar || initials(user.name)}</div>;
}

const navItems = [
  { href: '/', label: 'Accueil', icon: HomeIcon },
  { href: '/live-withdrawals', label: 'Retraits en direct', icon: Banknote },
  { href: '/withdraw', label: 'Retraits', icon: WalletCards },
  { href: '/profile', label: 'Profil', icon: UserRound },
];

function Shell({ children, title, eyebrow = 'Ton espace GainEase' }: { children: ReactNode; title?: string; eyebrow?: string }) {
  const [location, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const user = currentUser();
  const { signOut } = useClerk();
  if (!user) { setLocation('/auth'); return null; }
  const logout = () => { localStorage.removeItem(KEYS.current); localStorage.removeItem(KEYS.token); void signOut({ redirectUrl: `${basePath}/` }); };
  return <div className="gainease-shell min-h-[100dvh] bg-[#f2f8f8] text-[#1d2948]">
    <aside className="gainease-sidebar fixed inset-y-0 left-0 z-40 hidden w-[242px] flex-col bg-[#18245d] px-5 py-6 text-white lg:flex">
      <Logo light />
      <div className="mt-12 px-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[#8490c1]">Navigation</div>
      <nav className="mt-3 space-y-1.5">
        {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition ${location === href ? 'bg-[#293778] text-[#70f0e4]' : 'text-[#adb7dd] hover:bg-white/5 hover:text-white'}`} data-testid={`link-nav-${label.toLowerCase().replace(' ', '-')}`}><Icon size={18} /><span>{label}</span>{href === '/withdraw' && user.withdrawalStatus === 'pending' && <span className="ml-auto h-2 w-2 rounded-full bg-[#ffca67]" />}</Link>)}
        {user.isAdmin && <Link href="/admin" className={`mt-6 flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition ${location === '/admin' ? 'bg-[#293778] text-[#70f0e4]' : 'text-[#adb7dd] hover:bg-white/5 hover:text-white'}`} data-testid="link-nav-admin"><LayoutDashboard size={18} /><span>Administration</span></Link>}
      </nav>
      <div className="mt-auto rounded-2xl border border-white/10 bg-white/5 p-4">
        <div className="flex items-center gap-3"><Avatar user={user} small /><div className="min-w-0"><p className="truncate text-sm font-bold">{user.name}</p><p className="truncate text-[11px] text-[#9ea9d0]">{user.isAdmin ? 'Administrateur' : 'Membre vérifié'}</p></div></div>
        <button onClick={logout} className="mt-4 flex w-full items-center gap-2 text-xs font-semibold text-[#aeb9dd] transition hover:text-white" data-testid="button-logout-sidebar"><LogOut size={14} /> Déconnexion</button>
      </div>
    </aside>
    <div className="lg:pl-[242px]">
      <header className="gainease-topbar sticky top-0 z-30 border-b border-[#dfeeed] bg-[#f2f8f8]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1260px] items-center justify-between px-4 py-4 sm:px-7 lg:px-10">
          <div className="lg:hidden"><Logo /></div>
          <div className="hidden lg:block"><p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#6e8191]">{eyebrow}</p><h1 className="mt-1 text-lg font-extrabold tracking-[-0.03em]">{title}</h1></div>
          <div className="flex items-center gap-3">
            <div className="hidden text-right sm:block"><p className="text-xs font-bold">{user.name}</p><p className="text-[11px] text-[#71818f]">{user.email}</p></div>
            <Link href="/profile" data-testid="link-header-profile"><Avatar user={user} small /></Link>
            <button className="grid h-9 w-9 place-items-center rounded-xl border border-[#dcebea] bg-white lg:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu" data-testid="button-mobile-menu"><Menu size={18} /></button>
          </div>
        </div>
        {menuOpen && <div className="border-t border-[#dfeeed] bg-white px-4 py-3 lg:hidden"><div className="flex flex-wrap gap-2">{navItems.map(({ href, label }) => <Link key={href} href={href} onClick={() => setMenuOpen(false)} className={`rounded-lg px-3 py-2 text-xs font-bold ${location === href ? 'bg-[#18245d] text-white' : 'bg-[#eff7f7] text-[#526478]'}`} data-testid={`link-mobile-${label.toLowerCase().replace(' ', '-')}`}>{label}</Link>)}{user.isAdmin && <Link href="/admin" onClick={() => setMenuOpen(false)} className="rounded-lg bg-[#eff7f7] px-3 py-2 text-xs font-bold text-[#526478]" data-testid="link-mobile-admin">Admin</Link>}</div></div>}
      </header>
      <main className="gainease-main mx-auto max-w-[1260px] px-4 pb-28 pt-6 sm:px-7 sm:pt-8 lg:px-10 lg:pb-10">{children}</main>
    </div>
     <Link href="/support" className="fixed bottom-24 right-4 z-40 inline-flex items-center gap-2 rounded-full bg-[#18245d] px-4 py-3 text-xs font-extrabold text-white shadow-[0_10px_25px_rgba(24,36,93,0.2)] transition hover:-translate-y-0.5 hover:bg-[#293778] lg:bottom-6 lg:right-7" data-testid="link-support"><MessageCircle size={16} /> Support</Link>
     <nav className="gainease-bottom-nav fixed bottom-0 left-0 right-0 z-40 border-t border-[#dfeeed] bg-white/95 px-2 pb-[max(10px,env(safe-area-inset-bottom))] pt-2 backdrop-blur-xl lg:hidden">
      <div className="mx-auto flex max-w-md justify-around">{navItems.filter((item) => item.href !== '/withdraw').map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`flex min-w-[70px] flex-col items-center gap-1 rounded-xl px-2 py-1.5 text-[10px] font-bold ${location === href ? 'text-[#078c84]' : 'text-[#84909a]'}`} data-testid={`link-bottom-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={19} strokeWidth={location === href ? 2.7 : 2} /><span>{label}</span></Link>)}</div>
    </nav>
  </div>;
}

function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`gainease-card rounded-2xl border border-[#e0eeed] bg-white shadow-[0_8px_28px_rgba(31,68,76,0.055)] ${className}`}>{children}</section>;
}

function Metric({ label, value, sub, icon: Icon, tone = 'teal' }: { label: string; value: string; sub: string; icon: typeof TrendingUp; tone?: 'teal' | 'blue' | 'amber' }) {
  const colors = tone === 'blue' ? 'bg-[#e7edff] text-[#5265bd]' : tone === 'amber' ? 'bg-[#fff3d7] text-[#b67a17]' : 'bg-[#e1f8f3] text-[#087b6e]';
  return <Card className="gainease-metric p-4"><div className="flex items-center justify-between"><div><p className="text-xs font-semibold text-[#73818e]">{label}</p><p className="mt-1 text-[21px] font-extrabold tracking-[-0.04em] text-[#1d2948]">{value}</p></div><span className={`grid h-9 w-9 place-items-center rounded-xl ${colors}`}><Icon size={18} /></span></div><p className="mt-3 text-[11px] font-semibold text-[#84909a]">{sub}</p></Card>;
}

function Home() {
  const user = currentUser();
  const { flash, notify, clear } = useFlash();
  const [watching, setWatching] = useState(false);
  const [seconds, setSeconds] = useState(30);
  const [cooldown, setCooldown] = useState(0);
  const [busy, setBusy] = useState(false);
  const [activityTick, setActivityTick] = useState(0);
  if (!user) return <AuthRedirect />;
  const withdrawals = read<Withdrawal[]>(KEYS.withdrawals, []).filter((item) => item.userId === user.id && item.status !== 'rejected');
  const balance = Math.max(0, user.totalEarned - withdrawals.filter((item) => item.status === 'pending' || item.status === 'approved').reduce((sum, item) => sum + item.amount, 0));
  const activities = read<Activity[]>(KEYS.activities, []).filter((item) => item.userId === user.id);
  const progress = Math.min(100, (balance / 100) * 100);
  const eta = balance > 0 ? `${Math.max(1, Math.ceil((100 - balance) / 5))} vidéos de 30 secondes` : 'Commence par une vidéo de 30 secondes';
  useEffect(() => {
    if (!watching) return;
    const timer = window.setInterval(() => setSeconds((value) => {
      if (value <= 1) { window.clearInterval(timer); completeVideo(); return 0; }
      return value - 1;
    }), 1000);
    return () => window.clearInterval(timer);
  }, [watching]);
  useEffect(() => { if (cooldown <= 0) return; const timer = window.setInterval(() => setCooldown((value) => Math.max(0, value - 1)), 1000); return () => window.clearInterval(timer); }, [cooldown]);
  const completeVideo = () => {
    if (busy || !user) return;
    setBusy(true); setWatching(false); setCooldown(5);
    const users = read<User[]>(KEYS.users, []);
    const updated = users.map((item) => item.id === user.id ? { ...item, totalEarned: Number((item.totalEarned + 5).toFixed(2)), videoViews: item.videoViews + 1 } : item);
    write(KEYS.users, updated);
    write(KEYS.activities, [{ id: id('activity'), userId: user.id, type: 'video', title: 'Vidéo regardée', reward: 5, completedAt: new Date().toISOString() }, ...read<Activity[]>(KEYS.activities, [])]);
    addLog('Vidéo complétée · +5,00 €', user.name);
    setActivityTick((value) => value + 1); setBusy(false); notify('Bravo ! 5,00 € viennent de rejoindre ton solde.');
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js';
    script.onload = () => { const confetti = (window as unknown as { confetti?: (options: object) => void }).confetti; confetti?.({ particleCount: 120, spread: 80, origin: { y: 0.65 }, colors: ['#26D0CE', '#1A2980', '#ffca67'] }); };
    document.body.appendChild(script);
  };
  const startVideo = () => { if (cooldown > 0) { notify(`Encore ${cooldown} seconde${cooldown > 1 ? 's' : ''} avant la prochaine vidéo.`, 'info'); return; } setSeconds(30); setWatching(true); };
  const greetName = user.name.split(' ')[0];
  return <Shell title="Accueil">
    {flash && <Flash {...flash} onClose={clear} />}
    <div className="grid gap-5 xl:grid-cols-[1.4fr_0.8fr]">
      <section className="gainease-hero relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#1A2980] via-[#20368b] to-[#26D0CE] p-6 text-white shadow-[0_16px_34px_rgba(26,41,128,0.2)] sm:p-8">
        <div className="absolute -right-16 -top-24 h-64 w-64 rounded-full border-[34px] border-white/10" /><div className="absolute -bottom-28 right-28 h-56 w-56 rounded-full border-[24px] border-[#65efe0]/10" />
        <div className="relative"><div className="flex items-center gap-2 text-sm font-semibold text-[#c7fffa]"><Sparkles size={16} /> Ton argent, à ton rythme</div><h2 className="mt-5 max-w-lg text-[31px] font-extrabold leading-[1.06] tracking-[-0.06em] sm:text-[41px]">Bonjour {greetName},<br /><span className="text-[#70f0e4]">chaque geste compte.</span></h2><p className="mt-4 max-w-md text-sm leading-6 text-[#d7e3ff]">Regarde une courte vidéo, invite un proche et rapproche-toi de ton premier retrait de 100 €.</p><button onClick={startVideo} disabled={watching} className="mt-7 inline-flex items-center gap-2 rounded-xl bg-[#ffca67] px-5 py-3 text-sm font-extrabold text-[#25305d] shadow-[0_8px_18px_rgba(255,202,103,0.22)] transition hover:-translate-y-0.5 disabled:opacity-70" data-testid="button-watch-video"><Play size={16} fill="currentColor" /> {watching ? 'Vidéo en cours...' : 'Gagner 5 € maintenant'}</button></div>
      </section>
      <Card className="flex flex-col justify-between overflow-hidden p-6">
        <div className="flex items-start justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.15em] text-[#7b8b95]">Solde disponible</p><p className="mt-2 text-[40px] font-extrabold tracking-[-0.07em] text-[#1d2948]" data-testid="text-balance">{money(balance)}</p></div><span className="grid h-11 w-11 place-items-center rounded-xl bg-[#e7edff] text-[#5265bd]"><WalletCards size={21} /></span></div>
        <div className="mt-7"><div className="mb-2 flex justify-between text-xs font-bold"><span className="text-[#73818e]">Objectif premier retrait</span><span className="text-[#078c84]">{progress.toFixed(0)} %</span></div><div className="h-2.5 overflow-hidden rounded-full bg-[#e7eff1]"><div className="h-full rounded-full bg-gradient-to-r from-[#1A2980] to-[#26D0CE] transition-all duration-700" style={{ width: `${progress}%` }} /></div><p className="mt-3 text-xs text-[#73818e]">{eta}</p></div>
        <Link href="/withdraw" className={`mt-6 flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-extrabold transition ${balance >= 100 ? 'bg-[#18245d] text-white hover:bg-[#263678]' : 'bg-[#edf4f4] text-[#71818e]'}`} data-testid="link-withdraw-cta">Retirer mes gains <ArrowUpRight size={16} /></Link>
      </Card>
    </div>
    <div className="mt-5 grid gap-4 sm:grid-cols-3">
      <Metric label="Gains cumulés" value={money(user.totalEarned)} sub={`+${user.videoViews} vidéo${user.videoViews > 1 ? 's' : ''} regardée${user.videoViews > 1 ? 's' : ''}`} icon={TrendingUp} />
      <Metric label="Filleuls actifs" value={`${user.referrals}`} sub="Partage ton code pour accélérer" icon={Users} tone="blue" />
      <Metric label="Statut du compte" value="Vérifié" sub="Paiements protégés et suivis" icon={ShieldCheck} tone="amber" />
    </div>
    <div className="mt-5 grid gap-5 lg:grid-cols-[1.12fr_0.88fr]">
      <Card className="p-5 sm:p-6"><div className="flex items-center justify-between"><div><h3 className="font-extrabold tracking-[-0.03em]">Ton activité</h3><p className="mt-1 text-xs text-[#7b8b95]">Tes petites victoires des derniers jours</p></div><Link href="/profile" className="text-xs font-bold text-[#078c84]" data-testid="link-view-profile">Voir le profil <ChevronRight className="inline" size={14} /></Link></div>
        <div className="mt-5 grid grid-cols-7 gap-2">{Array.from({ length: 28 }, (_, index) => <div key={index} className={`aspect-square rounded-md ${index % 9 === 0 ? 'bg-[#26d0ce]' : index % 5 === 0 ? 'bg-[#b8ece5]' : index % 3 === 0 ? 'bg-[#e2f6f3]' : 'bg-[#eef5f5]'}`} title={`${index + 1} jour`} data-testid={`activity-grid-${index}`} />)}</div><div className="mt-4 flex items-center justify-between text-[10px] font-semibold text-[#8a979f]"><span>Il y a 4 semaines</span><span>Aujourd'hui</span></div>
      </Card>
      <Card className="p-5 sm:p-6"><div className="flex items-center justify-between"><div><h3 className="font-extrabold tracking-[-0.03em]">Dernières actions</h3><p className="mt-1 text-xs text-[#7b8b95]">Tes gains apparaissent ici</p></div><span className="rounded-lg bg-[#eff7f7] px-2 py-1 font-mono text-[10px] text-[#078c84]">{activities.length} action{activities.length > 1 ? 's' : ''}</span></div>
        <div className="mt-4 space-y-1">{activities.slice(0, 4).map((activity) => <div key={`${activity.id}-${activityTick}`} className="flex items-center gap-3 rounded-xl px-1 py-3"><span className={`grid h-9 w-9 place-items-center rounded-xl ${activity.type === 'video' ? 'bg-[#e7edff] text-[#5265bd]' : 'bg-[#fff3d7] text-[#b67a17]'}`}>{activity.type === 'video' ? <Play size={15} fill="currentColor" /> : <Gift size={16} />}</span><div className="min-w-0 flex-1"><p className="truncate text-xs font-bold">{activity.title}</p><p className="text-[10px] text-[#8a979f]">{dateLabel(activity.completedAt)}</p></div><span className="text-xs font-extrabold text-[#078c84]">+{money(activity.reward)}</span></div>)}{activities.length === 0 && <div className="rounded-xl bg-[#f4f9f9] px-4 py-5 text-center text-xs font-semibold text-[#7d8c95]"><Sparkles className="mx-auto mb-2 text-[#26d0ce]" size={20} />Ta première action est à portée de clic.</div>}</div>
      </Card>
    </div>
    {watching && <Modal title="Ta vidéo est en cours" onClose={() => setWatching(false)}><div className="text-center"><div className="mx-auto grid h-28 w-28 place-items-center rounded-full border-[10px] border-[#dff7f3] bg-[#eafbf8] text-3xl font-extrabold text-[#078c84]">{seconds}s</div><h3 className="mt-5 text-lg font-extrabold">Encore un petit effort</h3><p className="mt-2 text-sm leading-6 text-[#71818e]">Reste sur cette fenêtre jusqu'à la fin pour recevoir tes 5,00 €.</p><div className="mt-5 h-2 overflow-hidden rounded-full bg-[#e8f1f1]"><div className="h-full rounded-full bg-[#26d0ce] transition-all duration-1000" style={{ width: `${((30 - seconds) / 30) * 100}%` }} /></div></div></Modal>}
  </Shell>;
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return <div className="fixed inset-0 z-[60] grid place-items-center bg-[#15214d]/45 p-4 backdrop-blur-sm"><div className="w-full max-w-md rounded-2xl border border-white/60 bg-white p-6 shadow-2xl animate-in"><div className="flex items-center justify-between"><h2 className="text-lg font-extrabold tracking-[-0.03em]">{title}</h2><button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg bg-[#f0f6f6] text-[#71818e]" aria-label="Fermer" data-testid="button-close-modal"><X size={16} /></button></div><div className="mt-5">{children}</div></div></div>;
}

function AuthRedirect() { const [, setLocation] = useLocation(); useEffect(() => setLocation('/sign-in'), [setLocation]); return <div className="min-h-[100dvh] bg-[#f2f8f8]" />; }

function Auth() {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmation: '', terms: false, captcha: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const { flash, notify, clear } = useFlash();
  const failures = read<{ count: number; blockedUntil: number }>(KEYS.failures, { count: 0, blockedUntil: 0 });
  const remainingBlock = Math.max(0, failures.blockedUntil - Date.now());
  const challenge = 7 + 5;
  const update = (field: keyof typeof form, value: string | boolean) => setForm((current) => ({ ...current, [field]: value }));
  const submit = (event: FormEvent) => {
    event.preventDefault(); setError('');
    if (remainingBlock > 0) { setError(`Trop de tentatives. Réessaie dans ${Math.ceil(remainingBlock / 60000)} min.`); return; }
    if (!form.email.includes('@')) { setError('Entre une adresse e-mail valide.'); return; }
    if (form.password.length < 8) { setError('Ton mot de passe doit contenir au moins 8 caractères.'); return; }
    if (mode === 'signup' && !form.name.trim()) { setError('Indique ton prénom et ton nom.'); return; }
    if (mode === 'signup' && form.password !== form.confirmation) { setError('Les mots de passe ne correspondent pas.'); return; }
    if (mode === 'signup' && !form.terms) { setError('Accepte les conditions pour continuer.'); return; }
    const users = read<User[]>(KEYS.users, []);
    if (mode === 'signin') {
      const user = users.find((item) => item.email.toLowerCase() === form.email.toLowerCase() && item.passwordHash === hashPassword(form.password));
      if (!user) { const next = { count: failures.count + 1, blockedUntil: failures.count + 1 >= 10 ? Date.now() + 15 * 60 * 1000 : 0 }; write(KEYS.failures, next); setError(next.count >= 10 ? 'Accès bloqué 15 minutes après 10 tentatives.' : next.count >= 5 ? 'Vérification requise : résous le mini-CAPTCHA.' : 'E-mail ou mot de passe incorrect.'); return; }
      write(KEYS.failures, { count: 0, blockedUntil: 0 }); localStorage.setItem(KEYS.current, user.id); localStorage.setItem(KEYS.token, `demo.jwt.${user.id}.${Date.now()}`); setLocation(user.isAdmin ? '/admin' : '/'); return;
    }
    if (users.some((item) => item.email.toLowerCase() === form.email.toLowerCase())) { setError('Un compte existe déjà avec cet e-mail.'); return; }
    setBusy(true);
    const isAdmin = users.length === 0;
    const newUser: User = { id: id('user'), name: form.name.trim(), email: form.email.toLowerCase(), passwordHash: hashPassword(form.password), isAdmin, avatar: initials(form.name), createdAt: new Date().toISOString(), videoViews: 0, totalEarned: 0, referrals: 0, withdrawalStatus: 'blocked', referralCode: `GAIN-${Math.random().toString(36).slice(2, 7).toUpperCase()}` };
    write(KEYS.users, [...users, newUser]); write(KEYS.activities, read<Activity[]>(KEYS.activities, [])); localStorage.setItem(KEYS.current, newUser.id); localStorage.setItem(KEYS.token, `demo.jwt.${newUser.id}.${Date.now()}`); addLog('Création de compte', newUser.name); setBusy(false); notify('Compte créé. Bienvenue dans l’aventure GainEase !'); setTimeout(() => setLocation(isAdmin ? '/admin' : '/'), 500);
  };
  const googleDemo = () => {
    const users = read<User[]>(KEYS.users, []); let user = users.find((item) => item.email === 'demo@gainease.fr');
    if (!user) { user = { id: id('user'), name: 'Camille Martin', email: 'demo@gainease.fr', passwordHash: hashPassword('google-demo'), isAdmin: users.length === 0, avatar: 'CM', createdAt: new Date().toISOString(), videoViews: 3, totalEarned: 15, referrals: 1, withdrawalStatus: 'blocked', referralCode: `GAIN-${Math.random().toString(36).slice(2, 7).toUpperCase()}` }; write(KEYS.users, [...users, user]); write(KEYS.activities, [...read<Activity[]>(KEYS.activities, []), { id: id('activity'), userId: user.id, type: 'bonus', title: 'Bonus de bienvenue', reward: 15, completedAt: new Date().toISOString() }]); }
    localStorage.setItem(KEYS.current, user.id); localStorage.setItem(KEYS.token, `demo.google.${user.id}.${Date.now()}`); addLog('Connexion Google · démo locale', user.name); setLocation(user.isAdmin ? '/admin' : '/');
  };
  return <div className="gainease-auth min-h-[100dvh] bg-[#f2f8f8] lg:grid lg:grid-cols-[0.92fr_1.08fr]">
    <div className="gainease-auth-visual relative hidden overflow-hidden bg-gradient-to-br from-[#18245d] via-[#1A2980] to-[#26D0CE] p-12 text-white lg:flex lg:flex-col"><Logo light /><div className="relative z-10 mt-auto max-w-lg pb-10"><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#70f0e4]">La première étape vers 100 €</p><h1 className="mt-4 text-6xl font-extrabold leading-[0.97] tracking-[-0.08em]">Les petits gains,<br /><span className="text-[#ffca67]">en grand.</span></h1><p className="mt-6 max-w-sm text-sm leading-6 text-[#dce5ff]">Une façon claire et motivante de transformer quelques minutes par jour en projets qui comptent.</p><div className="mt-10 flex items-center gap-3 text-xs font-bold text-[#ccfffa]"><ShieldCheck size={17} /> Données stockées localement pour cette démo</div></div><div className="absolute -right-24 top-24 h-96 w-96 rounded-full border-[52px] border-white/10" /><div className="absolute -bottom-32 -left-20 h-72 w-72 rounded-full border-[30px] border-[#70f0e4]/15" /></div>
     <div className="gainease-auth-panel flex items-center justify-center px-4 py-8 sm:px-8"><div className="w-full max-w-[450px]"><div className="mb-8 lg:hidden"><Logo /></div><div className="mb-8"><p className="text-sm font-bold text-[#078c84]">Bienvenue sur GainEase</p><h2 className="mt-2 text-3xl font-extrabold tracking-[-0.06em] text-[#1d2948]">{mode === 'signin' ? 'Content de te revoir.' : 'Ton prochain gain commence ici.'}</h2><p className="mt-2 text-sm text-[#71818e]">{mode === 'signin' ? 'Retrouve ton solde et continue ta progression.' : 'Crée ton espace personnel en moins d’une minute.'}</p></div>
      <div className="mb-6 grid grid-cols-2 rounded-xl bg-[#e8f3f3] p-1"><button onClick={() => { setMode('signin'); setError(''); }} className={`rounded-lg py-2.5 text-xs font-extrabold ${mode === 'signin' ? 'bg-white text-[#18245d] shadow-sm' : 'text-[#71818e]'}`} data-testid="button-tab-signin">Se connecter</button><button onClick={() => { setMode('signup'); setError(''); }} className={`rounded-lg py-2.5 text-xs font-extrabold ${mode === 'signup' ? 'bg-white text-[#18245d] shadow-sm' : 'text-[#71818e]'}`} data-testid="button-tab-signup">Créer un compte</button></div>
      {flash && <Flash {...flash} onClose={clear} />}<form onSubmit={submit} className="space-y-4">{mode === 'signup' && <Field label="Prénom et nom" icon={UserRound}><input value={form.name} onChange={(event) => update('name', event.target.value)} placeholder="Ex. Léa Bernard" className="auth-input" data-testid="input-name" /></Field>}<Field label="Adresse e-mail" icon={Mail}><input type="email" value={form.email} onChange={(event) => update('email', event.target.value)} placeholder="toi@exemple.fr" className="auth-input" data-testid="input-email" /></Field><Field label="Mot de passe" icon={KeyRound}><input type="password" value={form.password} onChange={(event) => update('password', event.target.value)} placeholder="8 caractères minimum" className="auth-input" data-testid="input-password" /></Field>{mode === 'signup' && <Field label="Confirme ton mot de passe" icon={ShieldCheck}><input type="password" value={form.confirmation} onChange={(event) => update('confirmation', event.target.value)} placeholder="Retape ton mot de passe" className="auth-input" data-testid="input-confirmation" /></Field>}{failures.count >= 5 && mode === 'signin' && <div className="rounded-xl border border-[#f3dcaa] bg-[#fff8e8] p-3"><label className="text-xs font-bold text-[#8e671f]" htmlFor="captcha">Vérification : combien font 7 + 5 ?</label><input id="captcha" value={form.captcha} onChange={(event) => update('captcha', event.target.value)} className="auth-input mt-2" inputMode="numeric" placeholder="Ta réponse" data-testid="input-captcha" /></div>}{mode === 'signup' && <label className="flex items-start gap-2 text-xs leading-5 text-[#71818e]"><input type="checkbox" checked={form.terms} onChange={(event) => update('terms', event.target.checked)} className="mt-1 accent-[#078c84]" data-testid="checkbox-terms" /><span>J’accepte les conditions d’utilisation et la politique de confidentialité de GainEase.</span></label>}{error && <p className="rounded-xl bg-[#fff0ef] px-3 py-2.5 text-xs font-bold text-[#b4433e]" data-testid="status-auth-error">{error}</p>}<button disabled={busy || remainingBlock > 0 || (failures.count >= 5 && mode === 'signin' && form.captcha !== String(challenge))} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#18245d] px-4 py-3.5 text-sm font-extrabold text-white shadow-[0_8px_18px_rgba(24,36,93,0.18)] transition hover:bg-[#293778] disabled:cursor-not-allowed disabled:opacity-45" type="submit" data-testid="button-submit-auth">{busy ? 'Création en cours...' : mode === 'signin' ? 'Ouvrir mon espace' : 'Créer mon compte'}<ChevronRight size={17} /></button></form>
       <div className="my-5 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.15em] text-[#a0adb2]"><span className="h-px flex-1 bg-[#dfeceb]" />ou<span className="h-px flex-1 bg-[#dfeceb]" /></div><button onClick={googleDemo} className="flex w-full items-center justify-center gap-3 rounded-xl border border-[#d8e8e7] bg-white px-4 py-3 text-sm font-bold text-[#374563] transition hover:border-[#a8d9d5] hover:bg-[#f8fcfc]" data-testid="button-google"><span className="grid h-5 w-5 place-items-center rounded-full bg-[#f1f5ff] text-xs font-extrabold text-[#4285f4]">G</span> Continuer avec Google <span className="text-[10px] font-medium text-[#a0adb2]">(démo)</span></button><p className="mt-7 text-center text-[11px] leading-5 text-[#819098]"><ShieldCheck className="mr-1 inline text-[#078c84]" size={13} /> Connexion locale sécurisée pour la démonstration</p></div></div></div>;
}

function AuthLanding() {
  return <div className="gainease-auth min-h-[100dvh] bg-[#f2f8f8] lg:grid lg:grid-cols-[0.92fr_1.08fr]">
    <div className="gainease-auth-visual relative hidden overflow-hidden bg-gradient-to-br from-[#18245d] via-[#1A2980] to-[#26D0CE] p-12 text-white lg:flex lg:flex-col">
      <Logo light />
      <div className="relative z-10 mt-auto max-w-lg pb-10">
        <p className="text-sm font-bold uppercase tracking-[0.18em] text-[#70f0e4]">La première étape vers 100 €</p>
        <h1 className="mt-4 text-6xl font-extrabold leading-[0.97] tracking-[-0.08em]">Les petits gains,<br /><span className="text-[#ffca67]">en grand.</span></h1>
        <p className="mt-6 max-w-sm text-sm leading-6 text-[#dce5ff]">Une façon claire et motivante de transformer quelques minutes par jour en projets qui comptent.</p>
        <div className="mt-10 flex items-center gap-3 text-xs font-bold text-[#ccfffa]"><ShieldCheck size={17} /> Validation e-mail et connexion Google sécurisées</div>
      </div>
      <div className="absolute -right-24 top-24 h-96 w-96 rounded-full border-[52px] border-white/10" />
      <div className="absolute -bottom-32 -left-20 h-72 w-72 rounded-full border-[30px] border-[#70f0e4]/15" />
    </div>
    <div className="gainease-auth-panel flex items-center justify-center px-4 py-8 sm:px-8">
      <div className="w-full max-w-[450px]">
        <div className="mb-8 lg:hidden"><Logo /></div>
        <div className="mb-8">
          <p className="text-sm font-bold text-[#078c84]">Bienvenue sur GainEase</p>
          <h2 className="mt-2 text-3xl font-extrabold tracking-[-0.06em] text-[#1d2948]">Ton espace commence ici.</h2>
          <p className="mt-2 text-sm text-[#71818e]">Crée ton compte ou connecte-toi pour retrouver tes gains.</p>
        </div>
        <div className="space-y-3">
          <Link href="/sign-in" className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#18245d] px-4 py-3.5 text-sm font-extrabold text-white shadow-[0_8px_18px_rgba(24,36,93,0.18)] transition hover:bg-[#293778]" data-testid="link-sign-in">Se connecter <ChevronRight size={17} /></Link>
          <Link href="/sign-up" className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#d8e8e7] bg-white px-4 py-3.5 text-sm font-extrabold text-[#18245d] transition hover:border-[#9edfd8]" data-testid="link-sign-up">Créer un compte <ChevronRight size={17} /></Link>
        </div>
        <div className="my-6 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.15em] text-[#a0adb2]"><span className="h-px flex-1 bg-[#dfeceb]" />sécurisé<span className="h-px flex-1 bg-[#dfeceb]" /></div>
        <p className="text-center text-[11px] leading-5 text-[#819098]"><ShieldCheck className="mr-1 inline text-[#078c84]" size={13} /> Un code de validation sera envoyé à ton adresse e-mail à l’inscription.</p>
      </div>
    </div>
  </div>;
}

function Field({ label, icon: Icon, children }: { label: string; icon: typeof Mail; children: ReactNode }) {
  return <label className="block"><span className="mb-1.5 block text-xs font-bold text-[#42536a]">{label}</span><div className="relative"><Icon className="absolute left-3 top-1/2 -translate-y-1/2 text-[#91a0a9]" size={16} />{children}</div></label>;
}

function Withdraw() {
  const user = currentUser();
  const { flash, notify, clear } = useFlash();
  const [, setLocation] = useLocation();
  const [preview, setPreview] = useState('');
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'PayPal' | 'Virement bancaire' | ''>('');
  const [paypalEmail, setPaypalEmail] = useState('');
  const [bankDetails, setBankDetails] = useState({ country: 'France', city: '', email: '', firstName: '', lastName: '', rib: '' });
  const [kyc, setKyc] = useState('');
  if (!user) return <AuthRedirect />;
  const withdrawals = read<Withdrawal[]>(KEYS.withdrawals, []).filter((item) => item.userId === user.id);
  const balance = Math.max(0, user.totalEarned - withdrawals.filter((item) => item.status === 'pending' || item.status === 'approved').reduce((sum, item) => sum + item.amount, 0));
  const handleFile = (event: ChangeEvent<HTMLInputElement>, type: 'voucher' | 'kyc') => { const file = event.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => type === 'voucher' ? setPreview(String(reader.result)) : setKyc(String(reader.result)); reader.readAsDataURL(file); };
  const submitVoucher = () => {
    if (!preview || !name.trim()) { notify('Ajoute ton nom et une photo lisible du code.', 'error'); return; }
    const vouchers = read(KEYS.vouchers, []) as VoucherSubmission[];
    const users = read(KEYS.users, []) as User[];
    const submission: VoucherSubmission = { id: id('voucher'), userId: user.id, codeImage: preview, name: name.trim(), status: 'pending', submittedAt: new Date().toISOString() };
    write(KEYS.vouchers, [submission, ...vouchers]);
    write(KEYS.users, users.map((item) => item.id === user.id ? { ...item, withdrawalStatus: 'pending' } : item));
    addLog('Code Transcash soumis', user.name); notify('Code envoyé. Notre équipe va le vérifier sous peu.'); setTimeout(() => setLocation('/withdraw'), 600);
  };
  const submitWithdrawal = () => {
    const value = Number(amount);
    if (!value || value < 100) { notify('Le montant minimum pour un retrait est de 100 €.', 'error'); return; }
    if (value > balance) { notify('Le montant dépasse ton solde disponible.', 'error'); return; }
    if (value > 50 && !kyc) { notify('Ajoute une pièce d’identité pour ce montant.', 'error'); return; }
    if (!method) { notify('Choisis PayPal ou virement bancaire.', 'error'); return; }
    if (method === 'PayPal' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(paypalEmail)) { notify('Ajoute une adresse e-mail PayPal valide.', 'error'); return; }
    if (method === 'Virement bancaire' && (!bankDetails.city.trim() || !bankDetails.email.trim() || !bankDetails.firstName.trim() || !bankDetails.lastName.trim() || !bankDetails.rib.trim())) { notify('Complète toutes les coordonnées bancaires.', 'error'); return; }
    const existing = read(KEYS.withdrawals, []) as Withdrawal[];
    const details = method === 'PayPal'
      ? `E-mail PayPal : ${paypalEmail.trim()}`
      : `${bankDetails.firstName.trim()} ${bankDetails.lastName.trim()} · ${bankDetails.city.trim()} · ${bankDetails.email.trim()} · RIB ${bankDetails.rib.trim()}`;
    const request: Withdrawal = { id: id('withdrawal'), userId: user.id, amount: value, method, details, status: 'pending', createdAt: new Date().toISOString() };
    write(KEYS.withdrawals, [request, ...existing]);
    addLog(`Demande de retrait · ${money(value)} · ${method}`, user.name); notify('Demande reçue. Tu recevras un e-mail dès sa validation.'); setAmount(''); setMethod(''); setPaypalEmail(''); setBankDetails({ country: 'France', city: '', email: '', firstName: '', lastName: '', rib: '' }); setKyc('');
  };
  return <Shell title="Retraits" eyebrow="Ton argent, en toute clarté">
    {flash && <Flash {...flash} onClose={clear} />}
    <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-sm font-bold text-[#078c84]">Ton objectif devient concret</p><h2 className="mt-1 text-3xl font-extrabold tracking-[-0.06em]">Retirer mes gains</h2><p className="mt-2 max-w-xl text-sm text-[#71818e]">On t'accompagne à chaque étape, sans mauvaise surprise.</p></div><div className="rounded-xl bg-white px-4 py-3 shadow-sm"><p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#819098]">Solde disponible</p><p className="mt-1 text-xl font-extrabold text-[#078c84]" data-testid="text-withdraw-balance">{money(balance)}</p></div></div>
    {user.withdrawalStatus === 'blocked' && <Card className="overflow-hidden"><div className="grid lg:grid-cols-[1fr_0.85fr]"><div className="p-6 sm:p-8"><span className="inline-flex items-center gap-2 rounded-full bg-[#fff3d7] px-3 py-1.5 text-[11px] font-extrabold text-[#93691e]"><TicketCheck size={14} /> Déblocage requis</span><h3 className="mt-5 max-w-md text-2xl font-extrabold tracking-[-0.05em]">Un dernier geste avant ton premier retrait.</h3><p className="mt-3 max-w-md text-sm leading-6 text-[#71818e]">Achète un code Transcash de 50 € sur Dundle, puis envoie-nous sa photo. Cette vérification unique protège tous les paiements de la communauté.</p><a href="https://dundle.com/fr/transcash/" target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-sm font-extrabold text-[#078c84] underline decoration-[#9fe7df] underline-offset-4" data-testid="link-dundle">Acheter mon code sur Dundle <ArrowUpRight size={15} /></a></div><div className="bg-[#f7fbfb] p-6 sm:p-8"><p className="text-xs font-extrabold uppercase tracking-[0.15em] text-[#73818e]">Envoyer mon justificatif</p><label className="mt-4 flex min-h-36 cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-[#b8deda] bg-white p-4 text-center transition hover:border-[#26d0ce]">{preview ? <img src={preview} alt="Aperçu du code Transcash" className="max-h-28 rounded-lg object-contain" data-testid="img-voucher-preview" /> : <><ImageIcon className="text-[#26d0ce]" size={27} /><span className="mt-2 text-xs font-bold text-[#536779]">Photo du code Transcash</span><span className="mt-1 text-[10px] text-[#93a0a7]">JPG, PNG · aperçu instantané</span></>}<input type="file" accept="image/*" onChange={(event) => handleFile(event, 'voucher')} className="hidden" data-testid="input-voucher-image" /></label><input value={name} onChange={(event) => setName(event.target.value)} placeholder="Nom inscrit sur le compte" className="auth-input mt-3" data-testid="input-voucher-name" /><button onClick={submitVoucher} className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[#18245d] py-3 text-sm font-extrabold text-white transition hover:bg-[#293778]" data-testid="button-submit-voucher"><FileCheck2 size={16} /> Envoyer pour vérification</button></div></div></Card>}
    {user.withdrawalStatus === 'pending' && <Card className="p-6 sm:p-10"><div className="mx-auto max-w-lg text-center"><div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#fff3d7] text-[#b67a17]"><Clock3 size={30} /></div><p className="mt-6 text-xs font-extrabold uppercase tracking-[0.18em] text-[#b67a17]">Vérification en cours</p><h3 className="mt-2 text-2xl font-extrabold tracking-[-0.05em]">On regarde ça pour toi.</h3><p className="mt-3 text-sm leading-6 text-[#71818e]">Ton justificatif est bien reçu. La vérification prend généralement moins de 24 heures. Tu recevras une notification dès que les retraits seront disponibles.</p><div className="mt-7 flex items-center justify-center gap-2 text-xs font-bold text-[#078c84]"><Mail size={15} /> support@gainease.fr</div><a href="mailto:support@gainease.fr" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#eff7f7] px-4 py-3 text-xs font-extrabold text-[#078c84]" data-testid="link-withdraw-support">Contacter le support <ArrowUpRight size={14} /></a></div></Card>}
     {user.withdrawalStatus === 'unlocked' && <div className="grid gap-5 lg:grid-cols-[0.95fr_1.05fr]"><Card className="p-6"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#e1f8f3] text-[#078c84]"><BadgeCheck size={20} /></span><div><h3 className="font-extrabold">Retrait disponible</h3><p className="text-xs text-[#71818e]">Compte vérifié</p></div></div><div className="mt-7"><label className="text-xs font-bold text-[#536779]">Montant à retirer</label><div className="relative mt-2"><input type="number" min="100" max="1000" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="100" className="auth-input pr-12 text-2xl font-extrabold" data-testid="input-withdraw-amount" /><span className="absolute right-4 top-1/2 -translate-y-1/2 font-bold text-[#819098]">€</span></div><p className="mt-2 text-[11px] text-[#819098]">Minimum 100 € · maximum 1 000 € · disponible : {money(balance)}</p></div><div className="mt-6"><p className="text-xs font-bold text-[#536779]">Choisis où recevoir ton gain</p><div className="mt-3 grid grid-cols-2 gap-3"><button type="button" onClick={() => setMethod('PayPal')} className={`flex min-h-28 flex-col items-center justify-center gap-2 rounded-2xl border-2 p-3 transition ${method === 'PayPal' ? 'border-[#26d0ce] bg-[#e8faf7] shadow-sm' : 'border-[#e0eeed] bg-white hover:border-[#9edfd8]'}`} data-testid="button-method-paypal"><img src={paypalLogo} alt="PayPal" className="h-14 w-full object-contain" /><span className={`text-xs font-extrabold ${method === 'PayPal' ? 'text-[#078c84]' : 'text-[#536779]'}`}>PayPal</span></button><button type="button" onClick={() => setMethod('Virement bancaire')} className={`flex min-h-28 flex-col items-center justify-center gap-2 overflow-hidden rounded-2xl border-2 bg-white p-3 transition ${method === 'Virement bancaire' ? 'border-[#26d0ce] bg-[#e8faf7] shadow-sm' : 'border-[#e0eeed] hover:border-[#9edfd8]'}`} data-testid="button-method-bank"><img src={bankLogo} alt="Virement bancaire" className="h-14 w-full rounded-lg object-contain" /><span className={`text-xs font-extrabold ${method === 'Virement bancaire' ? 'text-[#078c84]' : 'text-[#536779]'}`}>Virement bancaire</span></button></div></div>{method && <div className="mt-6 rounded-2xl border border-[#dceceb] bg-[#f8fcfc] p-4"><div className="flex items-center gap-2"><Landmark size={16} className="text-[#078c84]" /><p className="text-sm font-extrabold">{method === 'PayPal' ? 'Coordonnées PayPal' : 'Coordonnées bancaires'}</p></div>{method === 'PayPal' ? <label className="mt-4 block text-xs font-bold text-[#536779]">E-mail PayPal<input type="email" value={paypalEmail} onChange={(event) => setPaypalEmail(event.target.value)} placeholder="toi@exemple.fr" className="auth-input mt-2" autoComplete="email" data-testid="input-paypal-email" /></label> : <div className="mt-4 grid gap-3 sm:grid-cols-2"><label className="text-xs font-bold text-[#536779]">Pays<input value={bankDetails.country} onChange={(event) => setBankDetails({ ...bankDetails, country: event.target.value })} className="auth-input mt-2" autoComplete="country-name" data-testid="input-bank-country" /></label><label className="text-xs font-bold text-[#536779]">Ville<div className="relative mt-2"><MapPin size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#91a0a9]" /><input value={bankDetails.city} onChange={(event) => setBankDetails({ ...bankDetails, city: event.target.value })} placeholder="Paris" className="auth-input pl-10" autoComplete="address-level2" data-testid="input-bank-city" /></div></label><label className="text-xs font-bold text-[#536779]">E-mail<input type="email" value={bankDetails.email} onChange={(event) => setBankDetails({ ...bankDetails, email: event.target.value })} placeholder="toi@exemple.fr" className="auth-input mt-2" autoComplete="email" data-testid="input-bank-email" /></label><label className="text-xs font-bold text-[#536779]">Prénom<input value={bankDetails.firstName} onChange={(event) => setBankDetails({ ...bankDetails, firstName: event.target.value })} className="auth-input mt-2" autoComplete="given-name" data-testid="input-bank-first-name" /></label><label className="text-xs font-bold text-[#536779]">Nom<input value={bankDetails.lastName} onChange={(event) => setBankDetails({ ...bankDetails, lastName: event.target.value })} className="auth-input mt-2" autoComplete="family-name" data-testid="input-bank-last-name" /></label><label className="text-xs font-bold text-[#536779] sm:col-span-2"><span className="flex items-center gap-2">RIB <span className="font-normal text-[#819098]">FR76…</span></span><input value={bankDetails.rib} onChange={(event) => setBankDetails({ ...bankDetails, rib: event.target.value })} placeholder="FR76 1234 5678 9012 3456 7890 123" className="auth-input mt-2" autoComplete="off" data-testid="input-bank-rib" /></label></div>}</div>}<label className="mt-5 block text-xs font-bold text-[#536779]">Pièce d’identité <span className="font-medium text-[#9aa5aa]">(obligatoire au-dessus de 50 €)</span><div className="mt-2 flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-[#b8deda] bg-[#f8fcfc] px-3 py-3 text-xs font-semibold text-[#71818e]"><FileImage size={17} className="text-[#078c84]" />{kyc ? 'Document ajouté' : 'Importer un document'}<input type="file" accept="image/*,.pdf" onChange={(event) => handleFile(event, 'kyc')} className="hidden" data-testid="input-kyc" /></div></label><button onClick={submitWithdrawal} disabled={!amount || Number(amount) < 100 || Number(amount) > Math.min(1000, balance) || !method} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#18245d] py-3.5 text-sm font-extrabold text-white transition hover:bg-[#293778] disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-submit-withdrawal"><Check size={16} /> Confirmer le retrait</button></Card><Card className="p-6"><div className="flex items-center justify-between"><div><h3 className="font-extrabold">Historique des retraits</h3><p className="mt-1 text-xs text-[#71818e]">Toutes tes demandes au même endroit</p></div><ListChecks className="text-[#26d0ce]" size={20} /></div><div className="mt-5 divide-y divide-[#edf3f3]">{withdrawals.map((item) => <div key={item.id} className="flex items-center gap-3 py-4" data-testid={`row-withdrawal-${item.id}`}><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#e7edff] text-[#5265bd]"><ArrowUpRight size={16} /></span><div className="flex-1"><p className="text-xs font-extrabold">{item.method}</p><p className="text-[10px] text-[#819098]">{item.details || 'Coordonnées enregistrées'}</p><p className="mt-0.5 text-[10px] text-[#819098]">{dateLabel(item.createdAt)}</p></div><div className="text-right"><p className="text-sm font-extrabold">{money(item.amount)}</p><p className={`text-[10px] font-bold ${item.status === 'rejected' ? 'text-red-500' : item.status === 'paid' ? 'text-[#078c84]' : 'text-[#b67a17]'}`}>{item.status === 'paid' ? 'Payé' : item.status === 'approved' ? 'Validé' : item.status === 'rejected' ? 'Refusé' : 'En attente'}</p></div></div>)}{withdrawals.length === 0 && <div className="py-12 text-center text-xs font-semibold text-[#819098]"><WalletCards className="mx-auto mb-3 text-[#b8deda]" size={26} />Ton premier retrait apparaîtra ici.</div>}</div></Card></div>}
  </Shell>;
}

const frenchNames = ['Nina & Thomas', 'Sophie L.', 'Karim B.', 'Élodie M.', 'Maxime R.', 'Inès P.', 'Lucas D.', 'Manon G.', 'Yanis K.', 'Chloé V.'];
function LiveWithdrawals() {
  const [feed, setFeed] = useState(() => Array.from({ length: 8 }, (_, index) => makePayout(index)));
  const [lastRefresh, setLastRefresh] = useState(new Date());
  useEffect(() => { const timer = window.setInterval(() => { setFeed((items) => [makePayout(Date.now()), ...items].slice(0, 8)); setLastRefresh(new Date()); }, 30000); return () => window.clearInterval(timer); }, []);
  const refresh = () => { setFeed((items) => [makePayout(Date.now()), ...items].slice(0, 8)); setLastRefresh(new Date()); };
  return <Shell title="Retraits en direct" eyebrow="La communauté GainEase"><div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="flex items-center gap-2 text-xs font-bold text-[#078c84]"><span className="live-dot" /> Activité en temps réel</div><h2 className="mt-2 text-3xl font-extrabold tracking-[-0.06em]">Ils passent à l'étape suivante.</h2><p className="mt-2 max-w-xl text-sm text-[#71818e]">Chaque retrait est une preuve simple : les petits gestes finissent par payer.</p></div><button onClick={refresh} className="inline-flex items-center gap-2 self-start rounded-xl border border-[#d8e9e7] bg-white px-4 py-2.5 text-xs font-extrabold text-[#526478] transition hover:border-[#26d0ce]" data-testid="button-refresh-feed"><RefreshCw size={15} /> Actualiser</button></div><div className="grid gap-5 lg:grid-cols-[0.72fr_1.28fr]"><Card className="relative overflow-hidden bg-gradient-to-br from-[#18245d] to-[#273e98] p-6 text-white sm:p-8"><div className="relative z-10"><span className="grid h-11 w-11 place-items-center rounded-xl bg-[#70f0e4]/15 text-[#70f0e4]"><Banknote size={22} /></span><p className="mt-12 text-5xl font-extrabold tracking-[-0.08em]">100–1 000 €</p><p className="mt-3 max-w-xs text-sm leading-6 text-[#c4d1f5]">Des retraits validés chaque jour par des membres comme toi.</p><div className="mt-8 flex items-center gap-3"><div className="flex -space-x-2">{['NM', 'SL', 'KB'].map((letter) => <span key={letter} className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#263987] bg-[#d9f5f1] text-[10px] font-extrabold text-[#078c84]">{letter}</span>)}</div><span className="text-xs font-semibold text-[#c4d1f5]">+ 2 400 membres actifs</span></div></div><div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full border-[34px] border-[#70f0e4]/10" /></Card><Card className="overflow-hidden"><div className="flex items-center justify-between border-b border-[#edf3f3] px-5 py-4"><div><h3 className="font-extrabold">Derniers paiements</h3><p className="mt-1 text-[11px] text-[#819098]">Mise à jour automatique toutes les 30 secondes</p></div><span className="font-mono text-[10px] text-[#819098]" data-testid="text-last-refresh">{lastRefresh.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</span></div><div className="divide-y divide-[#edf3f3]">{feed.map((item) => <div key={item.id} className="flex items-center gap-3 px-5 py-4 transition hover:bg-[#f8fcfc]" data-testid={`row-live-withdrawal-${item.id}`}><span className={`grid h-9 w-9 place-items-center rounded-xl ${item.method === 'PayPal' ? 'bg-[#e7edff] text-[#5265bd]' : 'bg-[#e1f8f3] text-[#078c84]'}`}>{item.method === 'PayPal' ? <CreditCard size={16} /> : <Banknote size={16} />}</span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="text-xs font-extrabold">{item.name}</p><span className={`rounded-full px-2 py-0.5 text-[9px] font-extrabold ${item.badge === 'Nouveau' ? 'bg-[#fff3d7] text-[#a87217]' : 'bg-[#e1f8f3] text-[#078c84]'}`}>{item.badge}</span></div><p className="mt-0.5 text-[10px] text-[#819098]">via {item.method} · {item.when}</p></div><span className="text-sm font-extrabold text-[#078c84]">{money(item.amount)}</span></div>)}</div></Card></div></Shell>;
}
function makePayout(seed: number) { const method = Math.random() < 0.6 ? 'PayPal' : 'Virement bancaire'; return { id: `feed-${seed}-${Math.random()}`, name: frenchNames[Math.floor(Math.random() * frenchNames.length)], amount: [100, 125, 250, 380, 500, 750, 1000][Math.floor(Math.random() * 7)], method, badge: Math.random() > 0.55 ? 'Confirmé' : 'Nouveau', when: `${Math.floor(Math.random() * 18) + 1} min` }; }

function Profile() {
  const user = currentUser(); const [, setLocation] = useLocation(); const { flash, notify, clear } = useFlash();
  if (!user) return <AuthRedirect />;
  const logout = () => { localStorage.removeItem(KEYS.current); localStorage.removeItem(KEYS.token); setLocation('/auth'); };
  const copyCode = async () => { await navigator.clipboard?.writeText(user.referralCode); notify('Code de parrainage copié.'); };
  return <Shell title="Profil" eyebrow="Ton identité GainEase">{flash && <Flash {...flash} onClose={clear} />}<div className="grid gap-5 lg:grid-cols-[0.75fr_1.25fr]"><Card className="overflow-hidden"><div className="h-28 bg-gradient-to-r from-[#1A2980] to-[#26D0CE]" /><div className="-mt-10 px-6 pb-6"><Avatar user={user} /><h2 className="mt-4 text-2xl font-extrabold tracking-[-0.05em]">{user.name}</h2><p className="mt-1 flex items-center gap-1.5 text-sm text-[#71818e]"><Mail size={14} /> {user.email}</p><span className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-[#e1f8f3] px-3 py-1.5 text-[11px] font-extrabold text-[#078c84]"><BadgeCheck size={14} /> Compte vérifié</span><div className="mt-7 border-t border-[#edf3f3] pt-5"><p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#819098]">Code de parrainage</p><div className="mt-2 flex items-center justify-between rounded-xl bg-[#f2f8f8] px-3 py-3"><span className="font-mono text-sm font-bold tracking-wider text-[#18245d]" data-testid="text-referral-code">{user.referralCode}</span><button onClick={copyCode} className="grid h-8 w-8 place-items-center rounded-lg bg-white text-[#078c84] shadow-sm" aria-label="Copier le code" data-testid="button-copy-referral"><Copy size={15} /></button></div><p className="mt-2 text-[11px] leading-5 text-[#819098]">Invite un proche et recevez chacun un bonus après sa première vidéo.</p></div><button onClick={logout} className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl border border-[#f0d8d6] py-3 text-xs font-extrabold text-[#b4433e] transition hover:bg-[#fff6f5]" data-testid="button-logout-profile"><LogOut size={15} /> Se déconnecter</button></div></Card><div className="space-y-5"><div className="grid gap-4 sm:grid-cols-3"><Metric label="Vidéos regardées" value={`${user.videoViews}`} sub="30 secondes à la fois" icon={Play} /><Metric label="Gains cumulés" value={money(user.totalEarned)} sub="Depuis ton inscription" icon={TrendingUp} tone="blue" /><Metric label="Filleuls" value={`${user.referrals}`} sub="Membres invités" icon={Users} tone="amber" /></div><Card className="p-6"><div className="flex items-center justify-between"><div><h3 className="font-extrabold">Détails du compte</h3><p className="mt-1 text-xs text-[#819098]">Tes informations restent simples et transparentes.</p></div><ShieldCheck className="text-[#26d0ce]" size={21} /></div><div className="mt-5 grid gap-4 sm:grid-cols-2"><div className="rounded-xl bg-[#f5f9f9] p-4"><p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#819098]">Membre depuis</p><p className="mt-2 text-sm font-extrabold">{dateLabel(user.createdAt).split(' à ')[0]}</p></div><div className="rounded-xl bg-[#f5f9f9] p-4"><p className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#819098]">Statut retrait</p><p className="mt-2 text-sm font-extrabold">{user.withdrawalStatus === 'blocked' ? 'À débloquer' : user.withdrawalStatus === 'pending' ? 'Vérification en cours' : 'Disponible'}</p></div></div></Card>{user.isAdmin && <Card className="flex items-center justify-between gap-4 border-[#cfe3ff] bg-[#f4f7ff] p-5"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#e3eaff] text-[#5265bd]"><LayoutDashboard size={19} /></span><div><p className="text-sm font-extrabold">Espace administrateur</p><p className="mt-1 text-xs text-[#71818e]">Gérer la communauté et les validations.</p></div></div><Link href="/admin" className="rounded-xl bg-[#18245d] px-3 py-2.5 text-xs font-extrabold text-white" data-testid="link-admin-shortcut">Ouvrir <ChevronRight className="inline" size={14} /></Link></Card>}</div></div></Shell>;
}

function Support() {
  const user = currentUser(); const { flash, notify, clear } = useFlash();
  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState<SupportMessage[]>(() => user ? read<SupportMessage[]>(KEYS.support, []).filter((item) => item.userId === user.id) : []);
  const reload = () => { if (user) setMessages(read<SupportMessage[]>(KEYS.support, []).filter((item) => item.userId === user.id)); };
  useEffect(() => {
    if (!user) return;
    const timer = window.setInterval(reload, 2000);
    return () => window.clearInterval(timer);
  }, [user?.id]);
  if (!user) return <AuthRedirect />;
  const sendMessage = (event: FormEvent) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text) { notify('Écris ton message avant de l’envoyer.', 'error'); return; }
    const message: SupportMessage = { id: id('support'), userId: user.id, sender: 'user', text, createdAt: new Date().toISOString(), read: false };
    const all = read<SupportMessage[]>(KEYS.support, []);
    write(KEYS.support, [...all, message]);
    addLog('Message envoyé au support', user.name);
    setMessages((items) => [...items, message]); setDraft('');
    notify('Message envoyé au support.');
  };
  const orderedMessages = [...messages].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  return <Shell title="Support" eyebrow="Une équipe à ton écoute">
    {flash && <Flash {...flash} onClose={clear} />}
    <div className="mb-6"><p className="flex items-center gap-2 text-sm font-bold text-[#078c84]"><MessageCircle size={16} /> Besoin d’aide ?</p><h2 className="mt-2 text-3xl font-extrabold tracking-[-0.06em]">Parlons-nous.</h2><p className="mt-2 max-w-xl text-sm text-[#71818e]">Pose ta question et notre équipe te répondra directement dans cette conversation.</p></div>
    <div className="grid gap-5 lg:grid-cols-[1.25fr_0.75fr]">
      <Card className="gainease-chat-card flex min-h-[560px] flex-col overflow-hidden">
        <div className="gainease-chat-header flex items-center gap-3 border-b border-[#edf3f3] bg-gradient-to-r from-[#18245d] to-[#273e98] px-5 py-4 text-white"><span className="grid h-10 w-10 place-items-center rounded-xl bg-white/15"><MessageCircle size={19} /></span><div><p className="text-sm font-extrabold">Support GainEase</p><p className="mt-0.5 flex items-center gap-1.5 text-[11px] text-[#c9d5f2]"><span className="h-1.5 w-1.5 rounded-full bg-[#70f0e4]" /> Réponse généralement sous 24 h</p></div></div>
        <div className="gainease-chat-messages flex-1 space-y-4 overflow-y-auto bg-[#fbfdfd] p-5 sm:p-6">
          {orderedMessages.length === 0 && <div className="mx-auto max-w-sm rounded-2xl border border-[#dceceb] bg-white p-5 text-center shadow-sm"><span className="mx-auto grid h-11 w-11 place-items-center rounded-xl bg-[#e1f8f3] text-[#078c84]"><MessageCircle size={21} /></span><p className="mt-3 text-sm font-extrabold">Bonjour {user.name.split(' ')[0]}.</p><p className="mt-1 text-xs leading-5 text-[#71818e]">Décris ta préoccupation ci-dessous. Nous sommes là pour t’aider avec ton compte, tes gains ou ton retrait.</p></div>}
          {orderedMessages.map((message) => <div key={message.id} className={`flex items-end gap-2 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`} data-testid={`message-support-${message.id}`}><div className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-5 ${message.sender === 'user' ? 'rounded-br-md bg-[#18245d] text-white' : 'rounded-bl-md border border-[#dceceb] bg-white text-[#33445f] shadow-sm'}`}><p>{message.text}</p><p className={`mt-1.5 text-[10px] ${message.sender === 'user' ? 'text-[#b8c7ef]' : 'text-[#93a0a7]'}`}>{message.sender === 'user' ? 'Vous' : 'Support GainEase'} · {dateLabel(message.createdAt)}</p></div></div>)}
        </div>
        <form onSubmit={sendMessage} className="border-t border-[#edf3f3] bg-white p-4"><div className="flex items-end gap-2"><textarea value={draft} onChange={(event) => setDraft(event.target.value)} rows={2} placeholder="Écris ta question ou ta préoccupation..." className="auth-input min-h-12 resize-none py-3" data-testid="input-support-message" /><button type="submit" className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#18245d] text-white transition hover:bg-[#293778]" aria-label="Envoyer le message" data-testid="button-send-support"><Send size={17} /></button></div><p className="mt-2 text-[10px] text-[#93a0a7]">N’envoie jamais ton mot de passe ou tes informations bancaires dans le chat.</p></form>
      </Card>
      <Card className="h-fit p-5 sm:p-6"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#e1f8f3] text-[#078c84]"><CircleHelp size={19} /></span><h3 className="mt-4 text-lg font-extrabold">Comment pouvons-nous t’aider ?</h3><div className="mt-4 space-y-3 text-xs leading-5 text-[#71818e]"><p><strong className="text-[#33445f]">Retrait en attente</strong><br />Envoie-nous le montant et la méthode choisie pour que nous puissions vérifier ta demande.</p><p><strong className="text-[#33445f]">Compte ou gains</strong><br />Explique-nous ce qui s’est passé avec le plus de détails possible.</p><p><strong className="text-[#33445f]">Protection</strong><br />L’équipe GainEase ne te demandera jamais ton mot de passe.</p></div></Card>
    </div>
  </Shell>;
}

function Admin() {
  const user = currentUser(); const [, setLocation] = useLocation(); const { flash, notify, clear } = useFlash(); const [, rerender] = useState(0); const [supportDraft, setSupportDraft] = useState(''); const [selectedSupportUserId, setSelectedSupportUserId] = useState(() => read<SupportMessage[]>(KEYS.support, []).find((item) => item.sender === 'user')?.userId || '');
  useEffect(() => { if (user && !user.isAdmin) setLocation('/'); }, [user?.id, user?.isAdmin, setLocation]);
  useEffect(() => { const timer = window.setInterval(() => rerender((value) => value + 1), 2000); return () => window.clearInterval(timer); }, []);
  if (!user) return <AuthRedirect />;
  if (!user.isAdmin) return null;
  const users = read<User[]>(KEYS.users, []); const vouchers = read<VoucherSubmission[]>(KEYS.vouchers, []); const withdrawals = read<Withdrawal[]>(KEYS.withdrawals, []); const logs = read<AppLog[]>(KEYS.logs, []); const supportMessages = read<SupportMessage[]>(KEYS.support, []);
  const pendingVouchers = vouchers.filter((item) => item.status === 'pending');
  const supportUsers = users.filter((member) => supportMessages.some((message) => message.userId === member.id));
  const activeSupportUserId = supportUsers.some((member) => member.id === selectedSupportUserId) ? selectedSupportUserId : supportUsers[0]?.id || '';
  const activeSupportUser = users.find((member) => member.id === activeSupportUserId);
  const activeSupportMessages = supportMessages.filter((message) => message.userId === activeSupportUserId).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  const validateVoucher = (voucher: VoucherSubmission, status: 'approved' | 'rejected') => { write(KEYS.vouchers, vouchers.map((item) => item.id === voucher.id ? { ...item, status } : item)); write(KEYS.users, users.map((item) => item.id === voucher.userId ? { ...item, withdrawalStatus: status === 'approved' ? 'unlocked' : 'blocked' } : item)); addLog(`${status === 'approved' ? 'Validation' : 'Refus'} d’un code Transcash`, user.name); notify(status === 'approved' ? 'Code validé, retraits débloqués.' : 'Soumission refusée.'); rerender((value) => value + 1); };
  const deleteUser = (target: User) => { if (target.id === user.id) { notify('Impossible de supprimer ton propre compte.', 'error'); return; } if (!window.confirm(`Supprimer le compte de ${target.name} ?`)) return; write(KEYS.users, users.filter((item) => item.id !== target.id)); addLog(`Compte supprimé · ${target.email}`, user.name); notify('Compte supprimé.'); rerender((value) => value + 1); };
  const sendSupportReply = (event: FormEvent) => {
    event.preventDefault();
    const text = supportDraft.trim();
    if (!activeSupportUser || !text) { notify('Sélectionne une conversation et écris une réponse.', 'error'); return; }
    const message: SupportMessage = { id: id('support'), userId: activeSupportUser.id, sender: 'admin', text, createdAt: new Date().toISOString(), read: true };
    write(KEYS.support, [...supportMessages, message]);
    addLog(`Réponse support · ${activeSupportUser.name}`, user.name);
    setSupportDraft(''); notify('Réponse envoyée.'); rerender((value) => value + 1);
  };
  return <Shell title="Administration" eyebrow="Pilotage GainEase">
    {flash && <Flash {...flash} onClose={clear} />}
    <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div><p className="flex items-center gap-2 text-xs font-bold text-[#078c84]"><ShieldCheck size={14} /> Accès administrateur</p><h2 className="mt-2 text-3xl font-extrabold tracking-[-0.06em]">Vue d'ensemble.</h2><p className="mt-2 text-sm text-[#71818e]">Les décisions importantes, sans bruit.</p></div>
      <span className="rounded-xl bg-[#fff3d7] px-3 py-2 text-xs font-extrabold text-[#946b20]">{pendingVouchers.length} validation{pendingVouchers.length !== 1 ? 's' : ''} en attente</span>
    </div>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <Metric label="Utilisateurs" value={`${users.length}`} sub="Comptes inscrits" icon={Users} />
      <Metric label="Revenus cumulés" value={money(users.reduce((sum, item) => sum + item.totalEarned, 0))} sub="Gains distribués" icon={BarChart3} tone="blue" />
      <Metric label="Retraits à suivre" value={`${withdrawals.filter((item) => item.status === 'pending').length}`} sub="Demandes en attente" icon={Clock3} tone="amber" />
      <Metric label="Codes à vérifier" value={`${pendingVouchers.length}`} sub="Dossiers reçus" icon={TicketCheck} />
    </div>
     <Card className="mt-5 overflow-hidden">
       <div className="flex flex-col gap-3 border-b border-[#edf3f3] px-5 py-4 sm:flex-row sm:items-center sm:justify-between"><div><h3 className="flex items-center gap-2 font-extrabold"><MessageCircle size={18} className="text-[#078c84]" /> Support utilisateurs</h3><p className="mt-1 text-xs text-[#819098]">Réponds directement aux préoccupations de la communauté.</p></div><span className="w-fit rounded-full bg-[#e1f8f3] px-2.5 py-1 text-[10px] font-extrabold text-[#078c84]">{supportUsers.length} conversation{supportUsers.length !== 1 ? 's' : ''}</span></div>
       {supportUsers.length === 0 ? <div className="p-10 text-center text-xs font-semibold text-[#819098]"><MessageCircle className="mx-auto mb-3 text-[#b8deda]" size={28} />Aucun message reçu pour le moment.</div> : <div className="grid min-h-[430px] lg:grid-cols-[0.34fr_0.66fr]">
         <div className="border-b border-[#edf3f3] bg-[#f8fcfc] p-3 lg:border-b-0 lg:border-r">{supportUsers.map((member) => { const unread = supportMessages.filter((message) => message.userId === member.id && message.sender === 'user' && !message.read).length; return <button key={member.id} type="button" onClick={() => setSelectedSupportUserId(member.id)} className={`mb-1 flex w-full items-center gap-3 rounded-xl p-3 text-left transition ${activeSupportUserId === member.id ? 'bg-white shadow-sm ring-1 ring-[#cfe8e5]' : 'hover:bg-white/80'}`} data-testid={`button-support-user-${member.id}`}><Avatar user={member} small /><span className="min-w-0 flex-1"><span className="block truncate text-xs font-extrabold text-[#33445f]">{member.name}</span><span className="mt-0.5 block truncate text-[10px] text-[#819098]">{member.email}</span></span>{unread > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-[#078c84] px-1 text-[9px] font-extrabold text-white">{unread}</span>}</button>; })}</div>
         <div className="flex min-h-[430px] flex-col">
           {activeSupportUser && <div className="flex items-center gap-3 border-b border-[#edf3f3] px-5 py-4"><Avatar user={activeSupportUser} small /><div><p className="text-sm font-extrabold">{activeSupportUser.name}</p><p className="text-[11px] text-[#819098]">{activeSupportUser.email}</p></div></div>}
           <div className="flex-1 space-y-3 overflow-y-auto bg-[#fbfdfd] p-5">{activeSupportMessages.map((message) => <div key={message.id} className={`flex ${message.sender === 'admin' ? 'justify-end' : 'justify-start'}`} data-testid={`admin-message-${message.id}`}><div className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-5 ${message.sender === 'admin' ? 'rounded-br-md bg-[#18245d] text-white' : 'rounded-bl-md border border-[#dceceb] bg-white text-[#33445f] shadow-sm'}`}><p>{message.text}</p><p className={`mt-1.5 text-[10px] ${message.sender === 'admin' ? 'text-[#b8c7ef]' : 'text-[#93a0a7]'}`}>{message.sender === 'admin' ? 'Vous' : activeSupportUser?.name || 'Utilisateur'} · {dateLabel(message.createdAt)}</p></div></div>)}</div>
           <form onSubmit={sendSupportReply} className="border-t border-[#edf3f3] bg-white p-4"><div className="flex items-end gap-2"><textarea value={supportDraft} onChange={(event) => setSupportDraft(event.target.value)} rows={2} placeholder="Écrire une réponse..." className="auth-input min-h-12 resize-none py-3" data-testid="input-admin-support-reply" /><button type="submit" className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#078c84] text-white transition hover:bg-[#087b6e]" aria-label="Envoyer la réponse" data-testid="button-admin-support-reply"><Send size={17} /></button></div></form>
         </div>
       </div>}
     </Card>
    <div className="mt-5 grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
      <Card className="overflow-hidden">
        <div className="border-b border-[#edf3f3] px-5 py-4"><h3 className="font-extrabold">Soumissions Transcash</h3><p className="mt-1 text-xs text-[#819098]">Prévisualise chaque justificatif avant de décider.</p></div>
        <div className="divide-y divide-[#edf3f3]">
          {pendingVouchers.map((voucher) => { const owner = users.find((item) => item.id === voucher.userId); return <div key={voucher.id} className="p-5" data-testid={`card-voucher-${voucher.id}`}><div className="flex flex-col gap-4 sm:flex-row"><div className="flex h-32 w-full items-center justify-center overflow-hidden rounded-xl bg-[#edf5f5] sm:w-40">{voucher.codeImage ? <img src={voucher.codeImage} alt={`Justificatif de ${voucher.name}`} className="h-full w-full object-contain" data-testid={`img-voucher-${voucher.id}`} /> : <ImageIcon className="text-[#9eb4b6]" />}</div><div className="flex-1"><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-extrabold">{voucher.name}</p><p className="mt-1 text-xs text-[#819098]">{owner?.email} · reçu le {dateLabel(voucher.submittedAt)}</p></div><span className="rounded-full bg-[#fff3d7] px-2 py-1 text-[9px] font-extrabold text-[#a87217]">En attente</span></div><div className="mt-6 flex gap-2"><button onClick={() => validateVoucher(voucher, 'approved')} className="inline-flex items-center gap-2 rounded-lg bg-[#078c84] px-3 py-2 text-xs font-extrabold text-white" data-testid={`button-validate-voucher-${voucher.id}`}><Check size={14} /> Valider</button><button onClick={() => validateVoucher(voucher, 'rejected')} className="inline-flex items-center gap-2 rounded-lg border border-[#f0d8d6] px-3 py-2 text-xs font-extrabold text-[#b4433e]" data-testid={`button-reject-voucher-${voucher.id}`}><X size={14} /> Refuser</button></div></div></div></div>; })}
          {pendingVouchers.length === 0 && <div className="p-12 text-center text-xs font-semibold text-[#819098]"><CheckCircle2 className="mx-auto mb-3 text-[#26d0ce]" size={28} />Aucune validation en attente.</div>}
        </div>
      </Card>
      <Card className="overflow-hidden">
        <div className="border-b border-[#edf3f3] px-5 py-4"><h3 className="font-extrabold">Journal d'activité</h3><p className="mt-1 text-xs text-[#819098]">Les actions sensibles sont tracées.</p></div>
        <div className="divide-y divide-[#edf3f3]">{logs.slice(0, 7).map((log) => <div key={log.id} className="flex gap-3 px-5 py-3.5"><span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-[#edf5ff] text-[#5265bd]"><ListChecks size={14} /></span><div><p className="text-xs font-bold">{log.action}</p><p className="mt-1 text-[10px] text-[#819098]">{log.actor} · {dateLabel(log.createdAt)}</p></div></div>)}{logs.length === 0 && <p className="p-10 text-center text-xs text-[#819098]">Le journal est encore calme.</p>}</div>
      </Card>
    </div>
    <Card className="mt-5 overflow-hidden">
      <div className="flex items-center justify-between border-b border-[#edf3f3] px-5 py-4"><div><h3 className="font-extrabold">Gestion des utilisateurs</h3><p className="mt-1 text-xs text-[#819098]">Comptes et statut de déblocage.</p></div><Users className="text-[#26d0ce]" size={20} /></div>
      <div className="overflow-x-auto"><table className="w-full min-w-[650px] text-left"><thead className="bg-[#f7fbfb] text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#819098]"><tr><th className="px-5 py-3">Membre</th><th className="px-5 py-3">Gains</th><th className="px-5 py-3">Statut</th><th className="px-5 py-3">Inscription</th><th className="px-5 py-3">Action</th></tr></thead><tbody className="divide-y divide-[#edf3f3]">{users.map((member) => <tr key={member.id} data-testid={`row-user-${member.id}`}><td className="px-5 py-3.5"><div className="flex items-center gap-3"><Avatar user={member} small /><div><p className="text-xs font-extrabold">{member.name} {member.isAdmin && <span className="ml-1 text-[9px] text-[#5265bd]">ADMIN</span>}</p><p className="text-[10px] text-[#819098]">{member.email}</p></div></div></td><td className="px-5 py-3.5 text-xs font-extrabold">{money(member.totalEarned)}</td><td className="px-5 py-3.5"><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${member.withdrawalStatus === 'unlocked' ? 'bg-[#e1f8f3] text-[#078c84]' : member.withdrawalStatus === 'pending' ? 'bg-[#fff3d7] text-[#a87217]' : 'bg-[#f0f3f4] text-[#71818e]'}`}>{member.withdrawalStatus === 'unlocked' ? 'Débloqué' : member.withdrawalStatus === 'pending' ? 'En vérification' : 'Bloqué'}</span></td><td className="px-5 py-3.5 text-xs text-[#71818e]">{dateLabel(member.createdAt).split(' à ')[0]}</td><td className="px-5 py-3.5"><button onClick={() => deleteUser(member)} className="grid h-8 w-8 place-items-center rounded-lg text-[#a7b1b4] transition hover:bg-[#fff0ef] hover:text-[#b4433e]" aria-label={`Supprimer ${member.name}`} data-testid={`button-delete-user-${member.id}`}><Trash2 size={15} /></button></td></tr>)}</tbody></table></div>
    </Card>
  </Shell>;
}

const clerkAppearance = {
  baseTheme: shadcn,
  variables: {
    colorPrimary: '#1A2980',
    colorText: '#1d2948',
    colorTextSecondary: '#71818e',
    colorBackground: '#ffffff',
    borderRadius: '0.9rem',
    fontFamily: 'Inter, sans-serif',
  },
  elements: {
    card: 'shadow-none border-0',
    headerTitle: 'font-extrabold tracking-tight',
    headerSubtitle: 'text-[#71818e]',
    formButtonPrimary: 'bg-[#1A2980] hover:bg-[#18245d]',
    socialButtonsBlockButton: 'border-[#d8e8e7] hover:bg-[#f2f8f8]',
    formFieldInput: 'border-[#d8e8e7] focus:border-[#26D0CE] focus:ring-[#26D0CE]',
    footerActionLink: 'text-[#078c84] hover:text-[#1A2980]',
  },
};

const clerkLocalization = {
  ...frFR,
  signIn: {
    ...frFR.signIn,
    start: {
      ...frFR.signIn?.start,
      title: 'Se connecter à GainEase',
      subtitle: 'pour continuer vers ton espace',
    },
  },
  signUp: {
    ...frFR.signUp,
    start: {
      ...frFR.signUp?.start,
      title: 'Créer ton compte GainEase',
      subtitle: 'pour commencer à gagner',
    },
  },
};

function AuthLoading() {
  return <div className="grid min-h-[100dvh] place-items-center bg-[#f2f8f8]"><div className="flex items-center gap-3 text-sm font-bold text-[#1A2980]"><span className="h-3 w-3 animate-pulse rounded-full bg-[#26D0CE]" />Chargement de GainEase…</div></div>;
}

function ClerkLocalBridge() {
  const { isLoaded, user } = useUser();
  useEffect(() => {
    if (!isLoaded) return;
    if (user) syncLocalUser(user);
    else {
      localStorage.removeItem(KEYS.current);
      localStorage.removeItem(KEYS.token);
    }
  }, [isLoaded, user]);
  return null;
}

function ProtectedPage({ children }: { children: ReactNode }) {
  const { isLoaded, isSignedIn, user } = useUser();
  const [synced, setSynced] = useState(false);
  useEffect(() => {
    if (!isLoaded) return;
    if (isSignedIn && user) syncLocalUser(user);
    setSynced(true);
  }, [isLoaded, isSignedIn, user]);
  if (!isLoaded || (isSignedIn && !synced)) return <AuthLoading />;
  if (!isSignedIn) return <Redirect to="/sign-in" />;
  return <>{children}</>;
}

function HomeRoute() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <AuthLoading />;
  return isSignedIn ? <ProtectedPage><Home /></ProtectedPage> : <AuthLanding />;
}

function SignInPage() {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f2f8f8] px-4 py-8"><div className="w-full max-w-[450px]"><div className="mb-6 flex justify-center"><Logo /></div><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} appearance={clerkAppearance} /></div></div>;
}

function SignUpPage() {
  return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f2f8f8] px-4 py-8"><div className="w-full max-w-[450px]"><div className="mb-6 flex justify-center"><Logo /></div><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} appearance={clerkAppearance} /></div></div>;
}

function WithdrawRoute() { return <ProtectedPage><Withdraw /></ProtectedPage>; }
function LiveWithdrawalsRoute() { return <ProtectedPage><LiveWithdrawals /></ProtectedPage>; }
function ProfileRoute() { return <ProtectedPage><Profile /></ProtectedPage>; }
function SupportRoute() { return <ProtectedPage><Support /></ProtectedPage>; }
function AdminRoute() { return <ProtectedPage><Admin /></ProtectedPage>; }

function AppRouter() {
  return <ErrorBoundary resetKey={stripBase(window.location.pathname)}><Switch>
    <Route path="/" component={HomeRoute} />
    <Route path="/sign-in/*?" component={SignInPage} />
    <Route path="/sign-up/*?" component={SignUpPage} />
    <Route path="/auth" component={AuthLanding} />
    <Route path="/withdraw" component={WithdrawRoute} />
    <Route path="/live-withdrawals" component={LiveWithdrawalsRoute} />
    <Route path="/profile" component={ProfileRoute} />
    <Route path="/support" component={SupportRoute} />
    <Route path="/admin" component={AdminRoute} />
    <Route component={NotFound} />
  </Switch></ErrorBoundary>;
}

function App() {
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl || undefined}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    appearance={clerkAppearance}
    localization={clerkLocalization}
  >
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={basePath}><ClerkLocalBridge /><AppRouter /></WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  </ClerkProvider>;
}

export default App;