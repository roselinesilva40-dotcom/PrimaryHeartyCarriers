---
name: Monorepo package targeting
description: Dependency changes in this workspace must target the owning package rather than the repository root.
---

Use pnpm filters when adding or updating dependencies in this monorepo; root-level installs can trigger the workspace preinstall guard and place packages in the wrong workspace.

**Why:** The application is split into independently managed artifact packages, and the root package is not the runtime owner of their dependencies.

**How to apply:** Target the package name explicitly for frontend and API dependencies, then run each package's typecheck/build.